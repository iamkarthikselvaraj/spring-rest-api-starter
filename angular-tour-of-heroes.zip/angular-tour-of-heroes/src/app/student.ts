export class Students{
    id:number;
    name:string;
    passportnumber:string;
}
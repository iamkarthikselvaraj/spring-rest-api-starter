import { Component } from '@angular/core';
import {StudentService} from './student.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Tour of Heroes';
  records={}
  
constructor(private myFirstService:StudentService,private router:Router){}

ngOnInit(){
this.records=this.myFirstService.getData().subscribe(data => {
  console.log("we got data ==> ",data);
});
}

}

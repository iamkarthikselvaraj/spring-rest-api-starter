import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
import {Router} from '@angular/router';

import { Hero } from '../hero';
import { HeroService } from '../hero.service';

@Component({
  selector: 'app-heroes',
  templateUrl: './heroes.component.html',
  styleUrls: ['./heroes.component.css']
})
export class HeroesComponent implements OnInit {

  selectedHero: Hero;

  heroes: Hero[];

  constructor(private heroService: HeroService,private router:Router) { }

  ngOnInit() {
    this.getHeroes();
  }

  onSelect(hero: Hero,event): void {
    this.selectedHero = hero;
    $("#heros-list li").removeClass("active");
    $(event.target).addClass("active");
  }

  getHeroes(): void {
    this.heroService.getHeroes()
        .subscribe(heroes => this.heroes = heroes);
  }

  navigateToDash():void{
    alert("i am in");
    this.router.navigate(["dashboard"]);
  }
}
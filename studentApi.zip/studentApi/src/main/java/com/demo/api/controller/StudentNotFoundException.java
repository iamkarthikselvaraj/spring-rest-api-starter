package com.demo.api.controller;

public class StudentNotFoundException extends Exception {
	public StudentNotFoundException(String Id) {
		System.out.println("id " + Id);
	}
}
